"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_harmony_1 = require("discord-harmony");
class Scrim extends discord_harmony_1.DatabaseObject {
}
exports.Scrim = Scrim;
