"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const enlister_1 = require("../enlister");
class User extends enlister_1.Enlister {
}
exports.User = User;
