import { Enlister } from '../enlister'

export class User extends Enlister {
  
}
