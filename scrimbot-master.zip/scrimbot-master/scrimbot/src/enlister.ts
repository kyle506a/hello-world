import { DatabaseObject } from 'discord-harmony'

export class Enlister extends DatabaseObject {
  timezoneOffset: number = undefined
  region: string = undefined
}
