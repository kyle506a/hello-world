import { DatabaseObject } from 'discord-harmony'

export class Scrim extends DatabaseObject {
  startingTime: Date
  author: any
  messages: any[]
}
